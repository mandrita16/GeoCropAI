
export default {
  plugins: {
    autoprefixer: {},
  },
};
